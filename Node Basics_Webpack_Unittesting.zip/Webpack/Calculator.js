// import {} from './Math.js';
import * as All from './Math.js';

console.log('The addition is : ' + All.Addition(20,30));
