function Add(x,y){
  if(x<0 || y<0){
    return 'x and y should be greater than 0 ';
  }
  return x + y;
}
QUnit.test( "a test", function( assert ) {
  assert.equal( 1, "1", "String '1' and number 1 have the same value" );
  assert.equal(Add(10,20),30);
});