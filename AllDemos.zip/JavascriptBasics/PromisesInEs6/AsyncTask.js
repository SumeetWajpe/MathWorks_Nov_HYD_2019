// return a prmise Object

function MakeAPromise(){
    return new Promise(function(resolve,reject){
        var xmlhttpReqObj = new XMLHttpRequest();
        xmlhttpReqObj.onreadystatechange = function (){
                if(xmlhttpReqObj.readyState == 4 && xmlhttpReqObj.status == 200){
                    resolve(xmlhttpReqObj.responseText);// will invoke the resolve callback method from then() ~
             }
             else if(xmlhttpReqObj.readyState == 4 && xmlhttpReqObj.status !== 200){
                    reject(xmlhttpReqObj.status); // will invoke the reject callback method from then() ~
             }
         }
        xmlhttpReqObj.open('GET',"https://jsonplaceholder.typicode.com/postss"); // configuration !
        xmlhttpReqObj.send(); // makes a request !  
    });// eof Promise

}// eof MakeAPromise()
