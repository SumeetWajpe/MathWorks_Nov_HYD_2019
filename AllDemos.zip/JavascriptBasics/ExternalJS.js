function PrintMessage(){
    console.log('Message from external Javascript File !');
}

function Add(x,y){
    return x + y;
}