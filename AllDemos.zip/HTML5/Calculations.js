
onmessage = function(){
    // this.console.log(XMLHttpRequest);
    // document not available !
    
    var myArrayData = [];
    for(var i=0;i<2000;i++){
        myArrayData[i] = [];
        for(var j=0;j<2000;j++){
            myArrayData[i][j] = Math.random();
        }
    } 

    postMessage(myArrayData);
}

    
